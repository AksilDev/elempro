package com.example.elementpro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast


class RegisterActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val loginButton = findViewById<Button>(R.id.loginButton)
        loginButton.setOnClickListener {
            Log.e("Redirected", "Going dashboard")

            Toast.makeText(this, "Button is clicked!", Toast.LENGTH_LONG).show()

            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)

        }
    }
}