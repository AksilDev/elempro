package com.example.elementpro

import com.example.elementpro.R
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.elementpro.DashboardActivity
import com.example.elementpro.RegisterActivity


class LoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val usernameEditText = findViewById<EditText>(R.id.usernameEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)

        val loginButton = findViewById<Button>(R.id.loginButton)
        loginButton.setOnClickListener{
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if(username.isEmpty() || password.isEmpty()){

                Toast.makeText(this, "username & password cannot be empty!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //if true, not executed

            if (username == "axcel" && password == "macansantos") {

                val intent = Intent(this, DashboardActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_LONG).show()
            }

        }

        val RegisterButton = findViewById<Button>(R.id.RegisterButton)
        RegisterButton.setOnClickListener{
            Log.e("Redirected",  "Going to register")

            Toast.makeText(this, "Button is clicked!", Toast.LENGTH_LONG).show()

            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)


        }


    }
}