package com.example.elementpro


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.example.elementpro.DashboardActivity
import com.example.elementpro.DevelopersActivity

import com.example.elementpro.ProfileActivity
import com.example.elementpro.R
import com.example.elementpro.SettingsActivity

class DashboardActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Initialize buttons
        val logoutButton = findViewById<Button>(R.id.logoutButton)
        val profileButton = findViewById<Button>(R.id.profileButton)
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        val developersButton = findViewById<Button>(R.id.developersButton)


        logoutButton.setOnClickListener {

            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)

            Toast.makeText(this, "YOU GOT LOGGED OUT NIGGA", Toast.LENGTH_LONG).show()

        }


        profileButton.setOnClickListener {

            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }


        settingsButton.setOnClickListener {

            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }


        developersButton.setOnClickListener {

            val intent = Intent(this, DevelopersActivity::class.java)
            startActivity(intent)
        }
    }
}