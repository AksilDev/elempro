package com.example.elementpro

import android.app.Activity
import android.os.Bundle

class DevelopersActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developers)
    }
}